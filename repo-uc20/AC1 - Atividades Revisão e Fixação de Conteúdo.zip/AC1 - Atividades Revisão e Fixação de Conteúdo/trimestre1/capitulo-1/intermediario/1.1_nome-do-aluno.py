'''
1.1 Nome do aluno
Peça o nome do aluno e exiba com uma saudação.
'''

nome_usuario = input('Digite o seu nome: ')

print(f'Bem-vindo(a) {nome_usuario}!')