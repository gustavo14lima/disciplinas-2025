'''
🧠 Desafio Final

Crie um cartão de visita digital:

    Nome
    Curso
    E-mail
    Um emoji personalizado Use print(), sep, end, e f-strings.

'''

nome = 'Gustavo'
curso = 'Curso Técnico'
email = 'al.gustavo.araujo@colegiovictorino.com.br'
emoji = '😄'

print(f'Nome: {nome}', f'Curso: {curso}', f'E-mail: {email}', sep='\n', end='😄 \n')