'''
1.1 Mensagem simples

Use print() para exibir a mensagem:

Seja bem-vindo(a) ao curso de Python!

'''
# atribuindo mensagem em uma variavel
mensagem = 'Seja bem-vindo(a) ao curso de Python!'

# imprimindo variavel
print(mensagem)