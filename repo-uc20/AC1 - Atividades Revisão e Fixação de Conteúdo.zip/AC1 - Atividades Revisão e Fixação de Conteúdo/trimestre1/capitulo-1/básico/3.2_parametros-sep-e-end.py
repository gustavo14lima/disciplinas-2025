'''
3.2 Parâmetros sep e end
Mostre como separar valores com sep=' | ' e como finalizar com end=' 😄\n'.
'''

dia,mes,ano = 15,5,2025

print(dia,mes,ano,sep=' | ',end=' 😄\n')