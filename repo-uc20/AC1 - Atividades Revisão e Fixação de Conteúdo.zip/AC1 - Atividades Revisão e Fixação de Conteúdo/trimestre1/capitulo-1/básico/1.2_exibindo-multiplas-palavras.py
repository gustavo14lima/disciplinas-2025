'''
1.2 Exibindo múltiplas palavras

Utilize print() com vários argumentos para exibir:

Aluno: Ana - Turma: 3ºC
'''

# atribuindo mensagem em uma variavel
mensagem = 'Ana - Turma: 3ºC'

# imprimindo variavel
print(mensagem)