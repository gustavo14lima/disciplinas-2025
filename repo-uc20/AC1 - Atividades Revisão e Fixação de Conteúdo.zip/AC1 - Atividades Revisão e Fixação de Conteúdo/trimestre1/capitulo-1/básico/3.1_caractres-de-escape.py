'''
3.1 Caracteres de escape

Use \n para pular linha e \t para tabular:

Nome:	João
Turma:	3ºA
'''

nome = 'João'
turma = '3ºA'

print(f'Nome:\t{nome}\nTurma:\t{turma}')