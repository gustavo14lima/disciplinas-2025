'''
2.1 Concatenação com +

Declare duas variáveis (nome, turma) e exiba:

Bem-vindo(a), [nome], à turma [turma]!
'''

# Atribuindo nome à variável nome
nome = 'Gustavo'
# Atribuindo turma à variável turma
turma = '3°C'

print('Bem-vindo, ' + nome + ' à turma ' + turma + '!')
