'''
2.3 Contagem regressiva
Mostre uma contagem de 10 até 1 com for.
'''

contador = 11

for x in range(contador):
    contador -= 1
    print(contador)