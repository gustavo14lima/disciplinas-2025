'''
2.2 Números pares
Mostre os números pares entre 2 e 20 com range().
'''

for numero in range(2, 21, 2):
    print(numero)