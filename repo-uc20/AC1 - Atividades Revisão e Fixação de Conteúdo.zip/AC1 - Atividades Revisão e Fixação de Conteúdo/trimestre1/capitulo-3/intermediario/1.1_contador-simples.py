'''
1.1 Contador simples
Imprima os números de 1 a 10 usando while.
'''

contador = 1

while contador < 11:
    print(contador)
    contador += 1