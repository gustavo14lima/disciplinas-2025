'''
1.1 Tipos primitivos
Declare três variáveis: um número inteiro, um número decimal e um valor booleano. Exiba o tipo de cada uma com type().
'''

numero_inteiro = 69
numero_decimal = 69.69
valor_booleano = True

print(f'Número inteiro = {type(numero_inteiro)}')
print(f'Número decimal = {type(numero_decimal)}')
print(f'Valor Booleano = {type(valor_booleano)}')